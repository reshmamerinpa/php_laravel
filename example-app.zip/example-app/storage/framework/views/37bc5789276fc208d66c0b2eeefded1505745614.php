<!DOCTYPE html>
<html>
  <head>
     <title>register</title>
  </head>
  <h2>Registration</h2>
    <form method="POST" action="/registration">
                <div> First Name<input type="text"  id="fname" name="fname"></div><br>
                <div> Last Name<input type="lname"  id="lname" name="lname"></div><br>
                <div> Username <input type="username" id="username" name="username"></div><br>
                <div> Password<input type="password" id="password" name="password"></div><br>
                <div> <button type="submit" class="btn btn-primary">Submit</button></div>
            
    </form>


</html><?php /**PATH C:\xampp\htdocs\example-app\resources\views/user/registration.blade.php ENDPATH**/ ?>